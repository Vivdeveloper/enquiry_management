# Copyright (c) 2026, Vivek Choudhary and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class UserConfigurationDepartment(Document):
	pass
