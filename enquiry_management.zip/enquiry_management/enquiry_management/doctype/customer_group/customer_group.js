// Copyright (c) 2026, Vivek Choudhary and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Customer Group", {
// 	refresh(frm) {

// 	},
// });
