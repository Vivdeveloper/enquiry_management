# Copyright (c) 2026, Vivek Choudhary and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestCustomer(FrappeTestCase):
	pass
