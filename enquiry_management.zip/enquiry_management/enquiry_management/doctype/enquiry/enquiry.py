# Copyright (c) 2026, Vivek Choudhary and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document


class Enquiry(Document):
	pass


def get_permission_query_conditions(user):
	"""
	Returns SQL conditions to filter Enquiry records based on user permissions.
	Administrator can see all records, other users can see:
	- Records they created
	- Records where they are the current owner
	- Records assigned to them in Assignment Log (table_xlzm)
	- Records where segment matches user's configured segments
	- Records where sub_segment matches user's configured sub_segments
	- Records related to users in their reporting_to list
	"""
	if not user:
		user = frappe.session.user

	# Administrator can see all records
	if user == "Administrator":
		return None  # No additional conditions needed

	# Other users can see records they created OR current owner OR assigned to them OR matching segment/sub_segment OR reporting hierarchy
	return f"""(
		`tabEnquiry`.`created_by` = {frappe.db.escape(user)}
		OR `tabEnquiry`.`current_owner` = {frappe.db.escape(user)}
		OR `tabEnquiry`.`name` IN (
			SELECT `parent`
			FROM `tabAssignment Log`
			WHERE `assigned_user` = {frappe.db.escape(user)}
			AND `parenttype` = 'Enquiry'
			AND `assignment_status` = 'Assigned'
		)
		OR (
			`tabEnquiry`.`segment` IN (
				SELECT `segment`
				FROM `tabUser Configuration Segment`
				WHERE `parent` IN (
					SELECT `name`
					FROM `tabUser Configuration`
					WHERE `user` = {frappe.db.escape(user)}
				)
			)
			AND (
				NOT EXISTS (
					SELECT 1
					FROM `tabUser Configuration`
					WHERE `user` = {frappe.db.escape(user)}
					AND `self_creator` = 1
				)
				OR `tabEnquiry`.`created_by` = {frappe.db.escape(user)}
				OR `tabEnquiry`.`name` IN (
					SELECT `parent`
					FROM `tabAssignment Log`
					WHERE `assigned_user` = {frappe.db.escape(user)}
					AND `parenttype` = 'Enquiry'
					AND `assignment_status` = 'Assigned'
				)
			)
		)
		OR (
			`tabEnquiry`.`sub_segment` IN (
				SELECT `sub_segment`
				FROM `tabUser Configuration Sub Segment`
				WHERE `parent` IN (
					SELECT `name`
					FROM `tabUser Configuration`
					WHERE `user` = {frappe.db.escape(user)}
				)
			)
			AND (
				NOT EXISTS (
					SELECT 1
					FROM `tabUser Configuration`
					WHERE `user` = {frappe.db.escape(user)}
					AND `self_creator` = 1
				)
				OR `tabEnquiry`.`created_by` = {frappe.db.escape(user)}
				OR `tabEnquiry`.`name` IN (
					SELECT `parent`
					FROM `tabAssignment Log`
					WHERE `assigned_user` = {frappe.db.escape(user)}
					AND `parenttype` = 'Enquiry'
					AND `assignment_status` = 'Assigned'
				)
			)
		)
		OR `tabEnquiry`.`created_by` IN (
			SELECT uc.`user`
			FROM `tabUser Configuration` uc
			WHERE uc.`name` IN (
				SELECT rt.`parent`
				FROM `tabUser Configuration Reporting To` rt
				WHERE rt.`reporting_to` = {frappe.db.escape(user)}
			)
		)
		OR `tabEnquiry`.`current_owner` IN (
			SELECT uc.`user`
			FROM `tabUser Configuration` uc
			WHERE uc.`name` IN (
				SELECT rt.`parent`
				FROM `tabUser Configuration Reporting To` rt
				WHERE rt.`reporting_to` = {frappe.db.escape(user)}
			)
		)
		OR `tabEnquiry`.`name` IN (
			SELECT `parent`
			FROM `tabAssignment Log`
			WHERE `assigned_user` IN (
				SELECT uc.`user`
				FROM `tabUser Configuration` uc
				WHERE uc.`name` IN (
					SELECT rt.`parent`
					FROM `tabUser Configuration Reporting To` rt
					WHERE rt.`reporting_to` = {frappe.db.escape(user)}
				)
			)
			AND `parenttype` = 'Enquiry'
			AND `assignment_status` = 'Assigned'
		)
	)"""

	