// frappe.listview_settings['Enquiry'] = {
// 	onload: function(listview) {
// 		// Show filter information message
// 		show_permission_filter_info(listview);
// 	},

// 	refresh: function(listview) {
// 		// Refresh filter info when list refreshes
// 		show_permission_filter_info(listview);
// 	}
// };

// function show_permission_filter_info(listview) {
// 	// Only show for non-Administrator users
// 	if (frappe.session.user === 'Administrator') {
// 		return;
// 	}

// 	// Fetch user configuration to show active filters
// 	frappe.call({
// 		method: 'frappe.client.get_list',
// 		args: {
// 			doctype: 'User Configuration',
// 			filters: {
// 				user: frappe.session.user
// 			},
// 			fields: ['name']
// 		},
// 		callback: function(r) {
// 			let filter_details = [];

// 			if (r.message && r.message.length > 0) {
// 				// User Configuration exists, fetch full details
// 				frappe.call({
// 					method: 'frappe.client.get',
// 					args: {
// 						doctype: 'User Configuration',
// 						name: r.message[0].name
// 					},
// 					callback: function(r2) {
// 						if (r2.message) {
// 							let user_config = r2.message;

// 							// Show segment filters
// 							if (user_config.self_all_selected_segment == 1) {
// 								filter_details.push(`Segments: <strong>All (if assigned)</strong>`);
// 							} else if (user_config.segments && user_config.segments.length > 0) {
// 								let segments = user_config.segments.map(s => s.segment).join(', ');
// 								filter_details.push(`Segments: <strong>${segments}</strong>`);
// 							}

// 							// Show sub_segment filters
// 							if (user_config.self_all_selected_sub_segment == 1) {
// 								filter_details.push(`Sub Segments: <strong>All (if assigned)</strong>`);
// 							} else if (user_config.sub_segments && user_config.sub_segments.length > 0) {
// 								let sub_segments = user_config.sub_segments.map(s => s.sub_segment).join(', ');
// 								filter_details.push(`Sub Segments: <strong>${sub_segments}</strong>`);
// 							}
// 						}

// 						// Fetch team members (users who report to current user)
// 						frappe.call({
// 							method: 'frappe.client.get_list',
// 							args: {
// 								doctype: 'User Configuration Reporting To',
// 								filters: {
// 									reporting_to: frappe.session.user
// 								},
// 								fields: ['parent']
// 							},
// 							callback: function(r3) {
// 								if (r3.message && r3.message.length > 0) {
// 									// Get the user field from parent User Configuration
// 									let parent_names = r3.message.map(rt => rt.parent);
// 									frappe.call({
// 										method: 'frappe.client.get_list',
// 										args: {
// 											doctype: 'User Configuration',
// 											filters: [
// 												['name', 'in', parent_names]
// 											],
// 											fields: ['user']
// 										},
// 										callback: function(r4) {
// 											if (r4.message && r4.message.length > 0) {
// 												let team_members = r4.message.map(uc => uc.user).join(', ');
// 												filter_details.push(`Team Members: <strong>${team_members}</strong>`);
// 											}
// 											show_filter_message(listview, filter_details);
// 										}
// 									});
// 								} else {
// 									show_filter_message(listview, filter_details);
// 								}
// 							}
// 						});
// 					}
// 				});
// 			} else {
// 				// No User Configuration found, show basic message
// 				show_filter_message(listview, filter_details);
// 			}
// 		}
// 	});
// }

// function show_filter_message(listview, filter_details) {
// 	let message = `
// 		<div style="padding: 10px; background-color: #f0f4ff; border-left: 3px solid #2490ef; margin-bottom: 10px;">
// 			<strong>Active Permission Filters:</strong><br>
// 			You are viewing enquiries based on:<br>
// 			• Records you created or own<br>
// 			• Records directly assigned to you in Assignment Log
// 			${filter_details.length > 0 ? '<br>• Records matching: ' + filter_details.join(' | ') : ''}
// 		</div>
// 	`;

// 	// Remove existing message if any
// 	listview.$page.find('.permission-filter-info').remove();

// 	// Add new message
// 	$(message).addClass('permission-filter-info').prependTo(listview.$page.find('.page-content .frappe-list'));
// }
